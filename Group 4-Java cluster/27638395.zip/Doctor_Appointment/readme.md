1st step - run all the commands given in sqlCommands.sql folder in mySql.

2nd step - open the code in an ide

3rd step- in the jdbcutil class change the username and password of the mySql 

4th step- run the project