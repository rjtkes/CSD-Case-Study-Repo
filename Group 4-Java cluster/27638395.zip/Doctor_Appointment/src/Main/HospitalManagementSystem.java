package Main;

import java.sql.Date;
import java.sql.Time;
import java.util.List;
import java.util.Scanner;

import Model.Appointment;
import Model.Doctor;
import Model.Patient;
import Service.AppointmentDAO;
import Service.DoctorDAO;
import Service.PatientDAO;

public class HospitalManagementSystem {

    private static PatientDAO patientDAO = new PatientDAO();
    private static DoctorDAO doctorDAO = new DoctorDAO();
    private static AppointmentDAO appointmentDAO = new AppointmentDAO();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Hospital Management System ---");
            System.out.println("1. Manage Patients");
            System.out.println("2. Manage Doctors");
            System.out.println("3. Manage Appointments");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    managePatients(scanner);
                    break;
                case 2:
                    manageDoctors(scanner);
                    break;
                case 3:
                    manageAppointments(scanner);
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void managePatients(Scanner scanner) {
        System.out.println("\n--- Manage Patients ---");
        System.out.println("1. Add Patient");
        System.out.println("2. View All Patient");
        System.out.println("3. View Patient By Id");
        System.out.println("4. Update Patient");
        System.out.println("5. Delete Patient");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
        case 1:
            addPatient(scanner);
            break;
        case 2:
            viewAllPatients(); // Handle the new option
            break;
        case 3:
            viewPatient(scanner);
            break;
        case 4:
            updatePatient(scanner);
            break;
        case 5:
            deletePatient(scanner);
            break;
        default:
            System.out.println("Invalid choice. Please try again.");
    }
    }

    private static void addPatient(Scanner scanner) {
        System.out.print("Enter patient name: ");
        String name = scanner.next();
        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        Date dob = Date.valueOf(scanner.next());
        System.out.print("Enter gender: ");
        String gender = scanner.next();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.next();

        Patient patient = new Patient();
        patient.setName(name);
        patient.setDateOfBirth(dob);
        patient.setGender(gender);
        patient.setContactNumber(contactNumber);
        patientDAO.addPatient(patient);
    }
    
    private static void viewAllPatients() {
        List<Patient> patients = patientDAO.getAllPatients();
        if (!patients.isEmpty()) {
            System.out.println("\n--- List of Patients ---");
            for (Patient patient : patients) {
                System.out.println("Patient ID: " + patient.getPatientId());
                System.out.println("Name: " + patient.getName());
                System.out.println("Date of Birth: " + patient.getDateOfBirth());
                System.out.println("Gender: " + patient.getGender());
                System.out.println("Contact Number: " + patient.getContactNumber());
                System.out.println("-----------------------------");
            }
        } else {
            System.out.println("No patients found.");
        }
    }

    private static void viewPatient(Scanner scanner) {
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        Patient patient = patientDAO.getPatientById(patientId);
        if (patient != null) {
            System.out.println("Patient ID: " + patient.getPatientId());
            System.out.println("Name: " + patient.getName());
            System.out.println("Date of Birth: " + patient.getDateOfBirth());
            System.out.println("Gender: " + patient.getGender());
            System.out.println("Contact Number: " + patient.getContactNumber());
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void updatePatient(Scanner scanner) {
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        Patient patient = patientDAO.getPatientById(patientId);
        if (patient != null) {
            System.out.print("Enter new patient name: ");
            String name = scanner.next();
            System.out.print("Enter new date of birth (YYYY-MM-DD): ");
            Date dob = Date.valueOf(scanner.next());
            System.out.print("Enter new gender: ");
            String gender = scanner.next();
            System.out.print("Enter new contact number: ");
            String contactNumber = scanner.next();

            patient.setName(name);
            patient.setDateOfBirth(dob);
            patient.setGender(gender);
            patient.setContactNumber(contactNumber);
            patientDAO.updatePatient(patient);
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void deletePatient(Scanner scanner) {
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        patientDAO.deletePatient(patientId);
    }

    private static void manageDoctors(Scanner scanner) {
        System.out.println("\n--- Manage Doctors ---");
        System.out.println("1. Add Doctor");
        System.out.println("2. View All Doctors");
        System.out.println("3. View Doctor By Id");
        System.out.println("4. Update Doctor");
        System.out.println("5. Delete Doctor");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
        case 1:
            addDoctor(scanner);
            break;
        case 2:
            viewAllDoctors(); 
            break;
        case 3:
            viewDoctor(scanner);
            break;
        case 4:
            updateDoctor(scanner);
            break;
        case 5:
            deleteDoctor(scanner);
            break;
        default:
            System.out.println("Invalid choice. Please try again.");
    }
    }

    private static void addDoctor(Scanner scanner) {
        System.out.print("Enter doctor name: ");
        String name = scanner.next();
        System.out.print("Enter specialization: ");
        String specialization = scanner.next();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.next();

        Doctor doctor = new Doctor();
        doctor.setName(name);
        doctor.setSpecialization(specialization);
        doctor.setContactNumber(contactNumber);
        doctorDAO.addDoctor(doctor);
    }
    private static void viewAllDoctors() {
        List<Doctor> doctors = doctorDAO.getAllDoctors();
        if (!doctors.isEmpty()) {
            System.out.println("\n--- List of Doctors ---");
            for (Doctor doctor : doctors) {
                System.out.println("Doctor ID: " + doctor.getDoctorId());
                System.out.println("Name: " + doctor.getName());
                System.out.println("Specialization: " + doctor.getSpecialization());
                System.out.println("Contact Number: " + doctor.getContactNumber());
                System.out.println("-----------------------------");
            }
        } else {
            System.out.println("No doctors found.");
        }
    }

    private static void viewDoctor(Scanner scanner) {
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        Doctor doctor = doctorDAO.getDoctorById(doctorId);
        if (doctor != null) {
            System.out.println("Doctor ID: " + doctor.getDoctorId());
            System.out.println("Name: " + doctor.getName());
            System.out.println("Specialization: " + doctor.getSpecialization());
            System.out.println("Contact Number: " + doctor.getContactNumber());
        } else {
            System.out.println("Doctor not found.");
        }
    }

    private static void updateDoctor(Scanner scanner) {
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        Doctor doctor = doctorDAO.getDoctorById(doctorId);
        if (doctor != null) {
            System.out.print("Enter new doctor name: ");
            String name = scanner.next();
            System.out.print("Enter new specialization: ");
            String specialization = scanner.next();
            System.out.print("Enter new contact number: ");
            String contactNumber = scanner.next();

            doctor.setName(name);
            doctor.setSpecialization(specialization);
            doctor.setContactNumber(contactNumber);
            doctorDAO.updateDoctor(doctor);
        } else {
            System.out.println("Doctor not found.");
        }
    }

    private static void deleteDoctor(Scanner scanner) {
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        doctorDAO.deleteDoctor(doctorId);
    }

    private static void manageAppointments(Scanner scanner) {
    	System.out.println("\n--- Manage Appointments ---");
        System.out.println("1. Schedule Appointment");
        System.out.println("2. View All Appointment");
        System.out.println("3. View Appointment By Id");
        System.out.println("4. Update Appointment");
        System.out.println("5. Delete Appointment");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                scheduleAppointment(scanner);
                break;
            case 2:
                viewAllAppointments(); // Handle the new option
                break;
            case 3:
                viewAppointment(scanner);
                break;
            case 4:
                updateAppointment(scanner);
                break;
            case 5:
                deleteAppointment(scanner);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void scheduleAppointment(Scanner scanner) {
        System.out.print("Enter doctor ID: ");
        int doctorId = scanner.nextInt();
        System.out.print("Enter patient ID: ");
        int patientId = scanner.nextInt();
        System.out.print("Enter appointment date (YYYY-MM-DD): ");
        Date appointmentDate = Date.valueOf(scanner.next());
        System.out.print("Enter appointment time (HH:MM:SS): ");
        Time appointmentTime = Time.valueOf(scanner.next());

        Appointment appointment = new Appointment();
        appointment.setDoctorId(doctorId);
        appointment.setPatientId(patientId);
        appointment.setAppointmentDate(appointmentDate);
        appointment.setAppointmentTime(appointmentTime);
        appointmentDAO.scheduleAppointment(appointment);
    }
    private static void viewAllAppointments() {
        List<Appointment> appointments = appointmentDAO.getAllAppointments();
        if (!appointments.isEmpty()) {
            System.out.println("\n--- List of Appointments ---");
            for (Appointment appointment : appointments) {
                System.out.println("Appointment ID: " + appointment.getAppointmentId());
                System.out.println("Patient ID: " + appointment.getPatientId());
                System.out.println("Doctor ID: " + appointment.getDoctorId());
                System.out.println("Date: " + appointment.getAppointmentDate());
                System.out.println("Time: " + appointment.getAppointmentTime());
                System.out.println("-----------------------------");
            }
        } else {
            System.out.println("No appointments found.");
        }
    }

    private static void viewAppointment(Scanner scanner) {
        System.out.print("Enter appointment ID: ");
        int appointmentId = scanner.nextInt();
        Appointment appointment = appointmentDAO.getAppointmentById(appointmentId);
        if (appointment != null) {
            System.out.println("Appointment ID: " + appointment.getAppointmentId());
            System.out.println("Doctor ID: " + appointment.getDoctorId());
            System.out.println("Patient ID: " + appointment.getPatientId());
            System.out.println("Appointment Date: " + appointment.getAppointmentDate());
            System.out.println("Appointment Time: " + appointment.getAppointmentTime());
        } else {
            System.out.println("Appointment not found.");
        }
    }

    private static void updateAppointment(Scanner scanner) {
        System.out.print("Enter appointment ID: ");
        int appointmentId = scanner.nextInt();
        Appointment appointment = appointmentDAO.getAppointmentById(appointmentId);
        if (appointment != null) {
            System.out.print("Enter new doctor ID: ");
            int doctorId = scanner.nextInt();
            System.out.print("Enter new patient ID: ");
            int patientId = scanner.nextInt();
            System.out.print("Enter new appointment date (YYYY-MM-DD): ");
            Date appointmentDate = Date.valueOf(scanner.next());
            System.out.print("Enter new appointment time (HH:MM:SS): ");
            Time appointmentTime = Time.valueOf(scanner.next());

            appointment.setDoctorId(doctorId);
            appointment.setPatientId(patientId);
            appointment.setAppointmentDate(appointmentDate);
            appointment.setAppointmentTime(appointmentTime);
            appointmentDAO.updateAppointment(appointment);
        } else {
            System.out.println("Appointment not found.");
        }
    }

    private static void deleteAppointment(Scanner scanner) {
        System.out.print("Enter appointment ID: ");
        int appointmentId = scanner.nextInt();
        appointmentDAO.deleteAppointment(appointmentId);
    }
}

